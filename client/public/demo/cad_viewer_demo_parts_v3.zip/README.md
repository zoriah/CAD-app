# CAD Viewer Demo Parts (GLB)

Diese Demo-Dateien sind dafür gedacht, alle Funktionen deiner Webapp zu testen:
- Auswahl einzelner Teile (Tap/Click)
- Move / Rotate / Scale (WYSIWYG)
- Farbe pro Teil oder "apply to all"
- Sprengansicht (Explode) – funktioniert am besten mit `demo_assembly.glb`

## Empfohlen zum Testen
- **demo_assembly.glb**  (detailreich)
- **demo_assembly_low.glb** (mobile/low poly)

## Einzelteile (separate Dateien)
- inner_ring.glb
- outer_ring.glb
- roller.glb (ein einzelner Rollkörper)
- rollers_12.glb (12 Rollkörper im Kreis)
- shaft.glb
- key.glb (Passfeder)

## Tipp
In deiner App: **Dateien laden** → wähle `demo_assembly.glb`.
Dann:
1) Sprengansicht/Slider nutzen
2) einzelne Roller anklicken, verschieben, Farbe ändern
3) Auto-Rotate ein/aus

